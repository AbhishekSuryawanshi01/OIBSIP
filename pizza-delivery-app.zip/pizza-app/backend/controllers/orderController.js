const asyncHandler = require('express-async-handler');
const Order = require('../models/Order');
const Inventory = require('../models/Inventory');
const { sendEmail, emailTemplates } = require('../services/emailService');

// Helper: deduct stock after order
const deductStock = async (pizza) => {
  const updates = [];

  if (pizza.base?.item) updates.push({ id: pizza.base.item, qty: 1 });
  if (pizza.sauce?.item) updates.push({ id: pizza.sauce.item, qty: 1 });
  if (pizza.cheese?.item) updates.push({ id: pizza.cheese.item, qty: 1 });
  if (pizza.veggies?.length) pizza.veggies.forEach(v => updates.push({ id: v.item, qty: 1 }));
  if (pizza.meats?.length) pizza.meats.forEach(m => updates.push({ id: m.item, qty: 1 }));

  for (const { id, qty } of updates) {
    await Inventory.findByIdAndUpdate(id, { $inc: { stock: -qty } });
  }
};

// @desc    Create order (after payment success)
// @route   POST /api/orders
// @access  Private
const createOrder = asyncHandler(async (req, res) => {
  const { pizza, deliveryAddress, pricing, payment, notes } = req.body;

  const order = await Order.create({
    user: req.user._id,
    pizza,
    deliveryAddress,
    pricing,
    payment,
    notes,
    status: 'order_received',
    statusHistory: [{ status: 'order_received', note: 'Payment confirmed' }],
  });

  // Deduct inventory
  await deductStock(pizza);

  // Populate user for email
  await order.populate('user', 'name email');

  // Send confirmation email
  try {
    const template = emailTemplates.orderConfirmation(order.user.name, order);
    await sendEmail({ to: order.user.email, ...template });
  } catch (e) {
    console.error('Order email failed:', e.message);
  }

  res.status(201).json({ success: true, data: order });
});

// @desc    Get user's orders
// @route   GET /api/orders/my-orders
// @access  Private
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id })
    .sort({ createdAt: -1 })
    .populate('pizza.base.item pizza.sauce.item pizza.cheese.item', 'name');

  res.json({ success: true, count: orders.length, data: orders });
});

// @desc    Get single order
// @route   GET /api/orders/:id
// @access  Private
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('user', 'name email phone');

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  // Users can only see their own orders
  if (order.user._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to view this order');
  }

  res.json({ success: true, data: order });
});

// @desc    Get all orders (Admin)
// @route   GET /api/orders
// @access  Private/Admin
const getAllOrders = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const filter = status ? { status } : {};

  const total = await Order.countDocuments(filter);
  const orders = await Order.find(filter)
    .populate('user', 'name email phone')
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(Number(limit));

  res.json({
    success: true,
    count: orders.length,
    total,
    pages: Math.ceil(total / limit),
    currentPage: Number(page),
    data: orders,
  });
});

// @desc    Update order status (Admin)
// @route   PUT /api/orders/:id/status
// @access  Private/Admin
const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status, note } = req.body;
  const validStatuses = ['order_received', 'in_kitchen', 'sent_for_delivery', 'delivered', 'cancelled'];

  if (!validStatuses.includes(status)) {
    res.status(400);
    throw new Error('Invalid status value');
  }

  const order = await Order.findById(req.params.id).populate('user', 'name email');

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  order.status = status;
  order.statusHistory.push({ status, note: note || '', updatedAt: new Date() });
  await order.save();

  // Send status update email to user
  try {
    const template = emailTemplates.orderStatusUpdate(order.user.name, order);
    await sendEmail({ to: order.user.email, ...template });
  } catch (e) {
    console.error('Status email failed:', e.message);
  }

  res.json({ success: true, data: order });
});

// @desc    Get order stats (Admin)
// @route   GET /api/orders/stats
// @access  Private/Admin
const getOrderStats = asyncHandler(async (req, res) => {
  const stats = await Order.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        revenue: { $sum: '$pricing.total' },
      },
    },
  ]);

  const totalRevenue = await Order.aggregate([
    { $match: { 'payment.status': 'paid' } },
    { $group: { _id: null, total: { $sum: '$pricing.total' } } },
  ]);

  const todayOrders = await Order.countDocuments({
    createdAt: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) },
  });

  res.json({
    success: true,
    data: {
      byStatus: stats,
      totalRevenue: totalRevenue[0]?.total || 0,
      todayOrders,
      totalOrders: await Order.countDocuments(),
    },
  });
});

module.exports = { createOrder, getMyOrders, getOrderById, getAllOrders, updateOrderStatus, getOrderStats };
