import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { orderAPI } from '../../services/api';
import { FiShoppingBag, FiClock, FiCheckCircle, FiPlusCircle } from 'react-icons/fi';
import './User.css';

const STATUS_LABEL = {
  pending: 'Pending',
  order_received: 'Order Received',
  in_kitchen: 'In Kitchen 👨‍🍳',
  sent_for_delivery: 'Out for Delivery 🛵',
  delivered: 'Delivered ✅',
  cancelled: 'Cancelled',
};

const STATUS_BADGE = {
  pending: 'badge-muted',
  order_received: 'badge-info',
  in_kitchen: 'badge-warning',
  sent_for_delivery: 'badge-primary',
  delivered: 'badge-success',
  cancelled: 'badge-danger',
};

export default function UserDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    orderAPI.getMyOrders().then(res => {
      setOrders(res.data.data);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const activeOrders = orders.filter(o => !['delivered', 'cancelled'].includes(o.status));
  const completedOrders = orders.filter(o => o.status === 'delivered');

  return (
    <div className="page">
      {/* Hero Welcome */}
      <div className="dashboard-hero card">
        <div>
          <h1 className="dashboard-welcome">Hey, {user?.name?.split(' ')[0]}! 👋</h1>
          <p style={{ color: 'var(--text-muted)', marginTop: 6 }}>What are we crafting today?</p>
        </div>
        <Link to="/build-pizza" className="btn btn-primary btn-lg">
          <FiPlusCircle /> Build My Pizza
        </Link>
      </div>

      {/* Stats */}
      <div className="grid-3" style={{ margin: '24px 0' }}>
        <div className="card stat-card">
          <FiShoppingBag size={28} style={{ color: 'var(--primary)' }} />
          <div>
            <div className="stat-number">{orders.length}</div>
            <div className="stat-label">Total Orders</div>
          </div>
        </div>
        <div className="card stat-card">
          <FiClock size={28} style={{ color: 'var(--warning)' }} />
          <div>
            <div className="stat-number">{activeOrders.length}</div>
            <div className="stat-label">Active Orders</div>
          </div>
        </div>
        <div className="card stat-card">
          <FiCheckCircle size={28} style={{ color: 'var(--success)' }} />
          <div>
            <div className="stat-number">{completedOrders.length}</div>
            <div className="stat-label">Delivered</div>
          </div>
        </div>
      </div>

      {/* Active Orders */}
      {activeOrders.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <h2 style={{ marginBottom: 16, fontSize: 20 }}>🔥 Active Orders</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {activeOrders.map(order => (
              <Link to={`/my-orders/${order._id}`} key={order._id} className="order-card card">
                <div className="order-card-left">
                  <div className="order-number">#{order.orderNumber}</div>
                  <div className="order-items">
                    {order.pizza?.base?.name} · {order.pizza?.sauce?.name} · {order.pizza?.cheese?.name}
                  </div>
                </div>
                <div className="order-card-right">
                  <span className={`badge ${STATUS_BADGE[order.status]}`}>
                    {STATUS_LABEL[order.status]}
                  </span>
                  <div className="order-price">₹{order.pricing?.total}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Recent Orders */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 20 }}>Recent Orders</h2>
          <Link to="/my-orders" className="btn btn-ghost btn-sm">View All</Link>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
        ) : orders.length === 0 ? (
          <div className="empty-state card">
            <div style={{ fontSize: 64 }}>🍕</div>
            <h3>No orders yet!</h3>
            <p>Time to craft your first masterpiece.</p>
            <Link to="/build-pizza" className="btn btn-primary" style={{ marginTop: 16 }}>
              <FiPlusCircle /> Build a Pizza
            </Link>
          </div>
        ) : (
          <div className="card table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 5).map(order => (
                  <tr key={order._id}>
                    <td>
                      <Link to={`/my-orders/${order._id}`} style={{ color: 'var(--primary-light)', fontWeight: 600 }}>
                        #{order.orderNumber}
                      </Link>
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{new Date(order.createdAt).toLocaleDateString()}</td>
                    <td style={{ fontWeight: 600 }}>₹{order.pricing?.total}</td>
                    <td><span className={`badge ${STATUS_BADGE[order.status]}`}>{STATUS_LABEL[order.status]}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
