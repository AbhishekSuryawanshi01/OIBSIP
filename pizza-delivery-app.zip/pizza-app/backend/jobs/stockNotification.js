const cron = require('node-cron');
const Inventory = require('../models/Inventory');
const { sendEmail, emailTemplates } = require('../services/emailService');

const checkLowStock = async () => {
  try {
    console.log('🔍 Running stock check...');

    // Find items that are low on stock and haven't had an alert sent yet
    const lowStockItems = await Inventory.find({
      $expr: { $lte: ['$stock', '$threshold'] },
      lowStockAlertSent: false,
      isAvailable: true,
    });

    if (lowStockItems.length === 0) {
      console.log('✅ Stock levels are healthy');
      return;
    }

    console.log(`⚠️ Found ${lowStockItems.length} low stock items`);

    // Send email alert to admin
    const template = emailTemplates.lowStockAlert(lowStockItems);
    await sendEmail({
      to: process.env.ADMIN_EMAIL,
      ...template,
    });

    // Mark alert as sent for these items
    const itemIds = lowStockItems.map(item => item._id);
    await Inventory.updateMany(
      { _id: { $in: itemIds } },
      { lowStockAlertSent: true }
    );

    console.log(`📧 Low stock alert sent for: ${lowStockItems.map(i => i.name).join(', ')}`);
  } catch (error) {
    console.error('❌ Stock check error:', error.message);
  }
};

const scheduleStockCheck = () => {
  // Run every hour
  cron.schedule('0 * * * *', checkLowStock, {
    scheduled: true,
    timezone: 'Asia/Kolkata',
  });

  // Also run every 15 mins for demo/testing
  cron.schedule('*/15 * * * *', checkLowStock, {
    scheduled: true,
    timezone: 'Asia/Kolkata',
  });

  console.log('📅 Stock notification job scheduled');
};

module.exports = { scheduleStockCheck, checkLowStock };
