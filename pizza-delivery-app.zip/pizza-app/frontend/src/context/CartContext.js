import React, { createContext, useContext, useState } from 'react';

const CartContext = createContext(null);

const DELIVERY_FEE = 49;
const TAX_RATE = 0.05;

export const CartProvider = ({ children }) => {
  const [customPizza, setCustomPizza] = useState({
    base: null,
    sauce: null,
    cheese: null,
    veggies: [],
    meats: [],
  });

  const calculatePricing = () => {
    const { base, sauce, cheese, veggies, meats } = customPizza;
    let subtotal = 0;
    if (base) subtotal += base.price;
    if (sauce) subtotal += sauce.price;
    if (cheese) subtotal += cheese.price;
    veggies.forEach((v) => (subtotal += v.price));
    meats.forEach((m) => (subtotal += m.price));
    const tax = Math.round(subtotal * TAX_RATE);
    const total = subtotal + tax + DELIVERY_FEE;
    return { subtotal, tax, deliveryFee: DELIVERY_FEE, total };
  };

  const selectBase = (item) => setCustomPizza((p) => ({ ...p, base: item }));
  const selectSauce = (item) => setCustomPizza((p) => ({ ...p, sauce: item }));
  const selectCheese = (item) => setCustomPizza((p) => ({ ...p, cheese: item }));

  const toggleVeggie = (item) => {
    setCustomPizza((p) => {
      const exists = p.veggies.find((v) => v._id === item._id);
      return {
        ...p,
        veggies: exists ? p.veggies.filter((v) => v._id !== item._id) : [...p.veggies, item],
      };
    });
  };

  const toggleMeat = (item) => {
    setCustomPizza((p) => {
      const exists = p.meats.find((m) => m._id === item._id);
      return {
        ...p,
        meats: exists ? p.meats.filter((m) => m._id !== item._id) : [...p.meats, item],
      };
    });
  };

  const resetPizza = () => {
    setCustomPizza({ base: null, sauce: null, cheese: null, veggies: [], meats: [] });
  };

  const isComplete = () => customPizza.base && customPizza.sauce && customPizza.cheese;

  return (
    <CartContext.Provider value={{ customPizza, selectBase, selectSauce, selectCheese, toggleVeggie, toggleMeat, resetPizza, calculatePricing, isComplete }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
};
