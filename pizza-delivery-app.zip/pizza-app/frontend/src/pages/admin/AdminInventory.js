import React, { useEffect, useState } from 'react';
import { inventoryAPI } from '../../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiAlertTriangle, FiPackage } from 'react-icons/fi';
import './Admin.css';

const CATEGORIES = ['base', 'sauce', 'cheese', 'veggie', 'meat'];

const EMPTY_FORM = { name: '', category: 'base', description: '', price: '', stock: '', threshold: 20, unit: 'units', imageUrl: '', isAvailable: true };

export default function AdminInventory() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [restockId, setRestockId] = useState(null);
  const [restockQty, setRestockQty] = useState('');

  const fetchItems = () => {
    setLoading(true);
    inventoryAPI.getAll(activeCategory || undefined)
      .then(res => setItems(res.data.data))
      .catch(() => toast.error('Failed to load inventory'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchItems(); }, [activeCategory]); // eslint-disable-line

  const openAdd = () => { setForm(EMPTY_FORM); setEditItem(null); setShowModal(true); };

  const openEdit = (item) => {
    setForm({ name: item.name, category: item.category, description: item.description || '', price: item.price, stock: item.stock, threshold: item.threshold, unit: item.unit, imageUrl: item.imageUrl || '', isAvailable: item.isAvailable });
    setEditItem(item);
    setShowModal(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.name || !form.price || form.stock === '') { toast.error('Please fill required fields'); return; }
    setSaving(true);
    try {
      if (editItem) {
        await inventoryAPI.update(editItem._id, form);
        toast.success('Item updated!');
      } else {
        await inventoryAPI.create(form);
        toast.success('Item added!');
      }
      setShowModal(false);
      fetchItems();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this item?')) return;
    try {
      await inventoryAPI.delete(id);
      toast.success('Item deleted');
      fetchItems();
    } catch (err) {
      toast.error('Delete failed');
    }
  };

  const handleRestock = async (id) => {
    if (!restockQty || restockQty <= 0) { toast.error('Enter valid quantity'); return; }
    try {
      await inventoryAPI.restock(id, restockQty);
      toast.success('Stock updated!');
      setRestockId(null);
      setRestockQty('');
      fetchItems();
    } catch (err) {
      toast.error('Restock failed');
    }
  };

  const lowStockItems = items.filter(i => i.stock <= i.threshold);

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Inventory</h1>
        <button className="btn btn-primary" onClick={openAdd}><FiPlus /> Add Item</button>
      </div>

      {/* Low Stock Alert Banner */}
      {lowStockItems.length > 0 && (
        <div className="low-stock-banner">
          <FiAlertTriangle size={18} />
          <span><strong>{lowStockItems.length} items</strong> are running low on stock: {lowStockItems.map(i => i.name).join(', ')}</span>
        </div>
      )}

      {/* Category Tabs */}
      <div className="category-tabs">
        <button className={`tab-btn ${activeCategory === '' ? 'tab-btn--active' : ''}`} onClick={() => setActiveCategory('')}>All</button>
        {CATEGORIES.map(c => (
          <button key={c} className={`tab-btn ${activeCategory === c ? 'tab-btn--active' : ''}`} onClick={() => setActiveCategory(c)}>
            {c.charAt(0).toUpperCase() + c.slice(1)}
          </button>
        ))}
      </div>

      {/* Inventory Table */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: 60 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
      ) : items.length === 0 ? (
        <div className="empty-state card">
          <FiPackage size={48} style={{ color: 'var(--text-dim)' }} />
          <h3>No items found</h3>
          <button className="btn btn-primary" onClick={openAdd}><FiPlus /> Add First Item</button>
        </div>
      ) : (
        <div className="card table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Threshold</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <React.Fragment key={item._id}>
                  <tr className={item.stock <= item.threshold ? 'row-low-stock' : ''}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ fontSize: 22 }}>{item.imageUrl || '📦'}</span>
                        <div>
                          <div style={{ fontWeight: 600 }}>{item.name}</div>
                          {item.description && <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{item.description}</div>}
                        </div>
                      </div>
                    </td>
                    <td><span className="badge badge-muted" style={{ textTransform: 'capitalize' }}>{item.category}</span></td>
                    <td style={{ fontWeight: 600 }}>₹{item.price}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontWeight: 700, color: item.stock <= item.threshold ? 'var(--danger)' : 'var(--success)' }}>{item.stock}</span>
                        {item.stock <= item.threshold && <FiAlertTriangle size={14} style={{ color: 'var(--danger)' }} />}
                      </div>
                      {/* Inline Restock */}
                      {restockId === item._id && (
                        <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                          <input
                            type="number"
                            className="form-input"
                            style={{ width: 80, padding: '4px 8px', fontSize: 12 }}
                            placeholder="Qty"
                            value={restockQty}
                            onChange={e => setRestockQty(e.target.value)}
                          />
                          <button className="btn btn-accent btn-sm" onClick={() => handleRestock(item._id)}>Add</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => { setRestockId(null); setRestockQty(''); }}>✕</button>
                        </div>
                      )}
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{item.threshold}</td>
                    <td>
                      <span className={`badge ${item.isAvailable ? 'badge-success' : 'badge-danger'}`}>
                        {item.isAvailable ? 'Available' : 'Unavailable'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost btn-sm" title="Restock" onClick={() => { setRestockId(item._id); setRestockQty(''); }}>+Stock</button>
                        <button className="btn btn-ghost btn-sm" onClick={() => openEdit(item)}><FiEdit2 size={14} /></button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(item._id)}><FiTrash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{editItem ? 'Edit Item' : 'Add Inventory Item'}</h3>
              <button className="modal-close" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <form onSubmit={handleSave} className="modal-body">
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Name *</label>
                  <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Classic Tomato" />
                </div>
                <div className="form-group">
                  <label className="form-label">Category *</label>
                  <select className="form-input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <input className="form-input" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Short description" />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Price (₹) *</label>
                  <input className="form-input" type="number" min="0" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Emoji / Image URL</label>
                  <input className="form-input" value={form.imageUrl} onChange={e => setForm({ ...form, imageUrl: e.target.value })} placeholder="🍕 or URL" />
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Stock *</label>
                  <input className="form-input" type="number" min="0" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Low Stock Threshold</label>
                  <input className="form-input" type="number" min="0" value={form.threshold} onChange={e => setForm({ ...form, threshold: e.target.value })} />
                </div>
              </div>
              <div className="form-group">
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.isAvailable} onChange={e => setForm({ ...form, isAvailable: e.target.checked })} />
                  <span style={{ fontSize: 14 }}>Available for ordering</span>
                </label>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" style={{ flex: 1 }} disabled={saving}>
                  {saving ? 'Saving...' : editItem ? 'Update Item' : 'Add Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
