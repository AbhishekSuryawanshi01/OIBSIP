import axios from 'axios';

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
});

// Attach token to every request
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
API.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ─── Auth ────────────────────────────────────────────────
export const authAPI = {
  register: (data) => API.post('/auth/register', data),
  login: (data) => API.post('/auth/login', data),
  verifyEmail: (token) => API.get(`/auth/verify-email/${token}`),
  forgotPassword: (email) => API.post('/auth/forgot-password', { email }),
  resetPassword: (token, password) => API.put(`/auth/reset-password/${token}`, { password }),
  resendVerification: (email) => API.post('/auth/resend-verification', { email }),
  getMe: () => API.get('/auth/me'),
};

// ─── Users ───────────────────────────────────────────────
export const userAPI = {
  getProfile: () => API.get('/users/profile'),
  updateProfile: (data) => API.put('/users/profile', data),
  changePassword: (data) => API.put('/users/change-password', data),
  getAllUsers: (page = 1) => API.get(`/users?page=${page}`),
  toggleStatus: (id) => API.put(`/users/${id}/toggle-status`),
};

// ─── Pizza ───────────────────────────────────────────────
export const pizzaAPI = {
  getOptions: () => API.get('/pizza/options'),
};

// ─── Inventory ───────────────────────────────────────────
export const inventoryAPI = {
  getAll: (category) => API.get(`/inventory${category ? `?category=${category}` : ''}`),
  getLowStock: () => API.get('/inventory/low-stock'),
  create: (data) => API.post('/inventory', data),
  update: (id, data) => API.put(`/inventory/${id}`, data),
  delete: (id) => API.delete(`/inventory/${id}`),
  restock: (id, quantity) => API.put(`/inventory/${id}/restock`, { quantity }),
};

// ─── Orders ──────────────────────────────────────────────
export const orderAPI = {
  create: (data) => API.post('/orders', data),
  getMyOrders: () => API.get('/orders/my-orders'),
  getById: (id) => API.get(`/orders/${id}`),
  getAllOrders: (params) => API.get('/orders', { params }),
  updateStatus: (id, status, note) => API.put(`/orders/${id}/status`, { status, note }),
  getStats: () => API.get('/orders/admin/stats'),
};

// ─── Payment ─────────────────────────────────────────────
export const paymentAPI = {
  createOrder: (amount) => API.post('/payment/create-order', { amount }),
  verify: (data) => API.post('/payment/verify', data),
  getKey: () => API.get('/payment/key'),
};

// ─── Admin ───────────────────────────────────────────────
export const adminAPI = {
  getDashboard: () => API.get('/admin/dashboard'),
};

export default API;
