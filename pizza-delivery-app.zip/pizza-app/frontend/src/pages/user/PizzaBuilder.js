import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { pizzaAPI } from '../../services/api';
import { useCart } from '../../context/CartContext';
import toast from 'react-hot-toast';
import { FiCheck, FiChevronRight, FiChevronLeft } from 'react-icons/fi';
import './User.css';

const STEPS = [
  { id: 0, label: 'Base', key: 'base', emoji: '🫓', desc: 'Choose your pizza base', single: true },
  { id: 1, label: 'Sauce', key: 'sauce', emoji: '🍅', desc: 'Pick your sauce', single: true },
  { id: 2, label: 'Cheese', key: 'cheese', emoji: '🧀', desc: 'Select your cheese', single: true },
  { id: 3, label: 'Veggies', key: 'veggies', emoji: '🥬', desc: 'Add veggies (optional, multiple)', single: false },
  { id: 4, label: 'Meats', key: 'meats', emoji: '🍗', desc: 'Add meats (optional, multiple)', single: false },
];

export default function PizzaBuilder() {
  const [step, setStep] = useState(0);
  const [options, setOptions] = useState({});
  const [loading, setLoading] = useState(true);
  const { customPizza, selectBase, selectSauce, selectCheese, toggleVeggie, toggleMeat, calculatePricing, isComplete, resetPizza } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    pizzaAPI.getOptions().then(res => setOptions(res.data.data)).catch(() => toast.error('Failed to load options')).finally(() => setLoading(false));
    resetPizza();
  }, []); // eslint-disable-line

  const currentStep = STEPS[step];
  const items = options[currentStep.key] || [];
  const pricing = calculatePricing();

  const getSelected = (key) => customPizza[key];

  const handleSelect = (item) => {
    const key = currentStep.key;
    if (key === 'base') selectBase(item);
    else if (key === 'sauce') selectSauce(item);
    else if (key === 'cheese') selectCheese(item);
    else if (key === 'veggies') toggleVeggie(item);
    else if (key === 'meats') toggleMeat(item);
  };

  const isItemSelected = (item) => {
    const key = currentStep.key;
    const sel = customPizza[key];
    if (Array.isArray(sel)) return sel.some(s => s._id === item._id);
    return sel?._id === item._id;
  };

  const canNext = () => {
    if (step < 3) {
      const key = STEPS[step].key;
      return !!customPizza[key];
    }
    return true; // veggies and meats are optional
  };

  const handleNext = () => {
    if (!canNext()) { toast.error(`Please select a ${currentStep.label}`); return; }
    if (step < STEPS.length - 1) setStep(step + 1);
    else {
      if (!isComplete()) { toast.error('Please complete all required steps'); return; }
      navigate('/checkout');
    }
  };

  if (loading) return <div className="loading-screen"><div className="spinner" /><p>Loading fresh ingredients...</p></div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">🍕 Build Your Pizza</h1>
      </div>

      {/* Step Indicators */}
      <div className="step-indicators">
        {STEPS.map((s, i) => (
          <div
            key={s.id}
            className={`step-indicator ${i === step ? 'step-indicator--active' : ''} ${i < step ? 'step-indicator--done' : ''}`}
            onClick={() => { if (i < step) setStep(i); }}
          >
            <div className="step-circle">
              {i < step ? <FiCheck size={14} /> : s.emoji}
            </div>
            <span className="step-label">{s.label}</span>
          </div>
        ))}
      </div>

      <div className="builder-layout">
        {/* Items Grid */}
        <div className="builder-main">
          <div className="card" style={{ marginBottom: 20 }}>
            <h2 style={{ marginBottom: 4 }}>{currentStep.emoji} {currentStep.label}</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>{currentStep.desc}</p>
          </div>

          {items.length === 0 ? (
            <div className="empty-state card">
              <p>No {currentStep.label} items available right now.</p>
            </div>
          ) : (
            <div className="ingredient-grid">
              {items.map(item => (
                <div
                  key={item._id}
                  className={`ingredient-card card ${isItemSelected(item) ? 'ingredient-card--selected' : ''}`}
                  onClick={() => handleSelect(item)}
                >
                  <div className="ingredient-emoji">{item.imageUrl || '🍕'}</div>
                  <div className="ingredient-name">{item.name}</div>
                  {item.description && <div className="ingredient-desc">{item.description}</div>}
                  <div className="ingredient-price">+₹{item.price}</div>
                  {isItemSelected(item) && (
                    <div className="ingredient-check"><FiCheck size={16} /></div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Summary Panel */}
        <div className="builder-summary">
          <div className="card" style={{ position: 'sticky', top: 24 }}>
            <h3 style={{ marginBottom: 16 }}>Your Pizza</h3>
            <div className="pizza-summary">
              {['base', 'sauce', 'cheese'].map(key => (
                <div key={key} className="summary-row">
                  <span className="summary-key">{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                  <span className="summary-val">{customPizza[key]?.name || '—'}</span>
                </div>
              ))}
              {customPizza.veggies.length > 0 && (
                <div className="summary-row">
                  <span className="summary-key">Veggies</span>
                  <span className="summary-val">{customPizza.veggies.map(v => v.name).join(', ')}</span>
                </div>
              )}
              {customPizza.meats.length > 0 && (
                <div className="summary-row">
                  <span className="summary-key">Meats</span>
                  <span className="summary-val">{customPizza.meats.map(m => m.name).join(', ')}</span>
                </div>
              )}
            </div>

            <div className="summary-divider" />

            <div className="pricing-breakdown">
              <div className="pricing-row"><span>Subtotal</span><span>₹{pricing.subtotal}</span></div>
              <div className="pricing-row"><span>Tax (5%)</span><span>₹{pricing.tax}</span></div>
              <div className="pricing-row"><span>Delivery</span><span>₹{pricing.deliveryFee}</span></div>
              <div className="pricing-row pricing-total"><span>Total</span><span>₹{pricing.total}</span></div>
            </div>

            <div className="builder-actions">
              {step > 0 && (
                <button className="btn btn-secondary" onClick={() => setStep(step - 1)}>
                  <FiChevronLeft /> Back
                </button>
              )}
              <button className="btn btn-primary" style={{ flex: 1 }} onClick={handleNext}>
                {step === STEPS.length - 1 ? 'Proceed to Checkout' : 'Next'}
                <FiChevronRight />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
