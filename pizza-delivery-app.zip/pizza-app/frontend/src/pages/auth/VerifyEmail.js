// VerifyEmail.js
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { authAPI } from '../../services/api';
import './Auth.css';

export function VerifyEmailPage() {
  const { token } = useParams();
  const [status, setStatus] = useState('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const verify = async () => {
      try {
        const res = await authAPI.verifyEmail(token);
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(res.data.user));
        setStatus('success');
      } catch (err) {
        setMessage(err.response?.data?.message || 'Verification failed');
        setStatus('error');
      }
    };
    verify();
  }, [token]);

  return (
    <div className="auth-page" style={{ justifyContent: 'center' }}>
      <div className="auth-form-panel" style={{ flex: '0 0 440px' }}>
        <div className="auth-form-wrapper">
          {status === 'loading' && (
            <div style={{ textAlign: 'center' }}>
              <div className="spinner" style={{ margin: '0 auto 16px' }} />
              <p>Verifying your email...</p>
            </div>
          )}
          {status === 'success' && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
              <h2 style={{ marginBottom: 12 }}>Email Verified!</h2>
              <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>Your account is ready. Let's get pizza!</p>
              <Link to="/login" className="btn btn-primary btn-full btn-lg">Go to Login</Link>
            </div>
          )}
          {status === 'error' && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 64, marginBottom: 16 }}>❌</div>
              <h2 style={{ marginBottom: 12 }}>Verification Failed</h2>
              <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>{message}</p>
              <Link to="/login" className="btn btn-secondary btn-full">Back to Login</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default VerifyEmailPage;
