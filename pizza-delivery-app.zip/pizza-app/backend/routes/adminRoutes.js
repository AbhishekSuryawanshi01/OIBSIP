const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { getOrderStats } = require('../controllers/orderController');
const { getLowStockItems } = require('../controllers/inventoryController');

// Admin dashboard summary
router.get('/dashboard', protect, adminOnly, async (req, res) => {
  const Order = require('../models/Order');
  const User = require('../models/User');
  const Inventory = require('../models/Inventory');

  const [
    totalOrders,
    todayOrders,
    pendingOrders,
    totalUsers,
    lowStockItems,
    revenueData,
    recentOrders,
  ] = await Promise.all([
    Order.countDocuments(),
    Order.countDocuments({ createdAt: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) } }),
    Order.countDocuments({ status: { $in: ['order_received', 'in_kitchen'] } }),
    User.countDocuments({ role: 'user' }),
    Inventory.find({ $expr: { $lte: ['$stock', '$threshold'] } }).select('name category stock threshold'),
    Order.aggregate([{ $match: { 'payment.status': 'paid' } }, { $group: { _id: null, total: { $sum: '$pricing.total' } } }]),
    Order.find().sort({ createdAt: -1 }).limit(5).populate('user', 'name email'),
  ]);

  res.json({
    success: true,
    data: {
      stats: {
        totalOrders,
        todayOrders,
        pendingOrders,
        totalUsers,
        totalRevenue: revenueData[0]?.total || 0,
        lowStockCount: lowStockItems.length,
      },
      lowStockItems,
      recentOrders,
    },
  });
});

module.exports = router;
