const express = require('express');
const router = express.Router();
const {
  getAllInventory,
  getAvailableByCategory,
  getAllAvailable,
  addInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getLowStockItems,
  restockItem,
} = require('../controllers/inventoryController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// Public (authenticated users) routes
router.get('/available', protect, getAllAvailable);
router.get('/available/:category', protect, getAvailableByCategory);

// Admin only routes
router.get('/', protect, adminOnly, getAllInventory);
router.get('/low-stock', protect, adminOnly, getLowStockItems);
router.post('/', protect, adminOnly, addInventoryItem);
router.put('/:id', protect, adminOnly, updateInventoryItem);
router.put('/:id/restock', protect, adminOnly, restockItem);
router.delete('/:id', protect, adminOnly, deleteInventoryItem);

module.exports = router;
