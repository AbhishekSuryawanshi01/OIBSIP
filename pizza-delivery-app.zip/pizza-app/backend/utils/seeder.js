const dotenv = require('dotenv');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
dotenv.config();

const connectDB = require('../config/db');
const User = require('../models/User');
const Inventory = require('../models/Inventory');

const inventoryData = [
  // Pizza Bases
  { name: 'Classic Hand-Tossed', category: 'base', description: 'Traditional thin crust hand-tossed dough', price: 99, stock: 100, threshold: 20, imageUrl: '🍕' },
  { name: 'Thin Crust', category: 'base', description: 'Light and crispy thin base', price: 89, stock: 80, threshold: 20, imageUrl: '🫓' },
  { name: 'Thick Pan Crust', category: 'base', description: 'Thick, fluffy pan-style dough', price: 109, stock: 60, threshold: 20, imageUrl: '🥖' },
  { name: 'Whole Wheat', category: 'base', description: 'Healthy whole wheat base', price: 119, stock: 50, threshold: 20, imageUrl: '🌾' },
  { name: 'Cheese Burst', category: 'base', description: 'Base filled with mozzarella cheese', price: 149, stock: 40, threshold: 20, imageUrl: '🧀' },

  // Sauces
  { name: 'Classic Tomato', category: 'sauce', description: 'Rich traditional tomato pizza sauce', price: 29, stock: 120, threshold: 25, imageUrl: '🍅' },
  { name: 'Pesto', category: 'sauce', description: 'Fresh basil pesto sauce', price: 49, stock: 80, threshold: 20, imageUrl: '🌿' },
  { name: 'BBQ', category: 'sauce', description: 'Smoky BBQ sauce', price: 39, stock: 90, threshold: 20, imageUrl: '🥫' },
  { name: 'White Garlic', category: 'sauce', description: 'Creamy garlic white sauce', price: 45, stock: 70, threshold: 20, imageUrl: '🧄' },
  { name: 'Spicy Arrabbiata', category: 'sauce', description: 'Spicy tomato arrabbiata sauce', price: 35, stock: 85, threshold: 20, imageUrl: '🌶️' },

  // Cheese
  { name: 'Mozzarella', category: 'cheese', description: 'Classic fresh mozzarella', price: 59, stock: 100, threshold: 25, imageUrl: '🧀' },
  { name: 'Cheddar', category: 'cheese', description: 'Sharp aged cheddar cheese', price: 69, stock: 80, threshold: 20, imageUrl: '🟡' },
  { name: 'Parmesan', category: 'cheese', description: 'Grated Parmesan cheese', price: 79, stock: 60, threshold: 20, imageUrl: '⭐' },
  { name: 'Ricotta', category: 'cheese', description: 'Creamy Italian ricotta', price: 75, stock: 50, threshold: 15, imageUrl: '🤍' },
  { name: 'Vegan Cheese', category: 'cheese', description: 'Plant-based cheese alternative', price: 89, stock: 40, threshold: 15, imageUrl: '🌱' },

  // Veggies
  { name: 'Bell Peppers', category: 'veggie', description: 'Fresh colorful bell peppers', price: 19, stock: 150, threshold: 30, imageUrl: '🫑' },
  { name: 'Mushrooms', category: 'veggie', description: 'Button mushrooms', price: 25, stock: 120, threshold: 30, imageUrl: '🍄' },
  { name: 'Black Olives', category: 'veggie', description: 'Sliced black olives', price: 29, stock: 100, threshold: 25, imageUrl: '⚫' },
  { name: 'Red Onions', category: 'veggie', description: 'Sliced red onions', price: 15, stock: 140, threshold: 30, imageUrl: '🧅' },
  { name: 'Jalapeños', category: 'veggie', description: 'Pickled jalapeño slices', price: 25, stock: 90, threshold: 20, imageUrl: '🌶️' },
  { name: 'Spinach', category: 'veggie', description: 'Fresh baby spinach', price: 20, stock: 80, threshold: 20, imageUrl: '🥬' },
  { name: 'Sun-dried Tomatoes', category: 'veggie', description: 'Tangy sun-dried tomatoes', price: 35, stock: 70, threshold: 15, imageUrl: '🍅' },
  { name: 'Sweet Corn', category: 'veggie', description: 'Golden sweet corn kernels', price: 19, stock: 110, threshold: 25, imageUrl: '🌽' },

  // Meats
  { name: 'Pepperoni', category: 'meat', description: 'Spicy pepperoni slices', price: 79, stock: 80, threshold: 20, imageUrl: '🍖' },
  { name: 'Chicken Tikka', category: 'meat', description: 'Spiced Indian chicken tikka', price: 89, stock: 70, threshold: 20, imageUrl: '🍗' },
  { name: 'BBQ Chicken', category: 'meat', description: 'Smoky BBQ pulled chicken', price: 85, stock: 65, threshold: 20, imageUrl: '🍗' },
  { name: 'Beef Meatballs', category: 'meat', description: 'Juicy Italian-style meatballs', price: 95, stock: 50, threshold: 15, imageUrl: '🥩' },
  { name: 'Ham', category: 'meat', description: 'Sliced honey-glazed ham', price: 75, stock: 60, threshold: 15, imageUrl: '🥓' },
];

const seedDB = async () => {
  await connectDB();

  try {
    // Clear existing data
    await User.deleteMany({});
    await Inventory.deleteMany({});

    console.log('🗑️  Cleared existing data');

    // Create admin user
    const adminPassword = await bcrypt.hash('Admin@123', 12);
    await User.create({
      name: 'Pizza Admin',
      email: 'admin@pizzadelivery.com',
      password: adminPassword,
      role: 'admin',
      isEmailVerified: true,
      phone: '9999999999',
    });

    // Create test user
    const userPassword = await bcrypt.hash('User@123', 12);
    await User.create({
      name: 'Test User',
      email: 'user@pizzadelivery.com',
      password: userPassword,
      role: 'user',
      isEmailVerified: true,
      phone: '8888888888',
      address: { street: '123 Main St', city: 'Mumbai', state: 'Maharashtra', pincode: '400001' },
    });

    console.log('👤 Created admin and test user');

    // Seed inventory
    await Inventory.insertMany(inventoryData);
    console.log(`🍕 Seeded ${inventoryData.length} inventory items`);

    console.log('\n✅ Database seeded successfully!');
    console.log('👑 Admin: admin@pizzadelivery.com / Admin@123');
    console.log('👤 User:  user@pizzadelivery.com / User@123');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
};

seedDB();
