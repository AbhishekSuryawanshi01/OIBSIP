import React, { useEffect, useState } from 'react';
import { orderAPI } from '../../services/api';
import toast from 'react-hot-toast';
import './Admin.css';

const STATUSES = [
  { value: '', label: 'All Orders' },
  { value: 'order_received', label: '✅ Order Received' },
  { value: 'in_kitchen', label: '👨‍🍳 In Kitchen' },
  { value: 'sent_for_delivery', label: '🛵 Out for Delivery' },
  { value: 'delivered', label: '🎉 Delivered' },
  { value: 'cancelled', label: '❌ Cancelled' },
];

const NEXT_STATUS = {
  order_received: { value: 'in_kitchen', label: '→ Move to Kitchen' },
  in_kitchen: { value: 'sent_for_delivery', label: '→ Send for Delivery' },
  sent_for_delivery: { value: 'delivered', label: '→ Mark Delivered' },
};

const STATUS_BADGE = {
  order_received: 'badge-info', in_kitchen: 'badge-warning',
  sent_for_delivery: 'badge-primary', delivered: 'badge-success',
  cancelled: 'badge-danger', pending: 'badge-muted',
};

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [updating, setUpdating] = useState(null);
  const [expanded, setExpanded] = useState(null);

  const fetchOrders = () => {
    setLoading(true);
    orderAPI.getAllOrders({ status: filter || undefined })
      .then(res => setOrders(res.data.data))
      .catch(() => toast.error('Failed to load orders'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchOrders(); }, [filter]); // eslint-disable-line

  const handleStatusUpdate = async (orderId, newStatus) => {
    setUpdating(orderId);
    try {
      await orderAPI.updateStatus(orderId, newStatus);
      toast.success('Order status updated!');
      fetchOrders();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally { setUpdating(null); }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Orders</h1>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {STATUSES.map(s => (
            <button
              key={s.value}
              className={`btn btn-sm ${filter === s.value ? 'btn-primary' : 'btn-ghost'}`}
              onClick={() => setFilter(s.value)}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 60 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
      ) : orders.length === 0 ? (
        <div className="empty-state card"><p>No orders found.</p></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {orders.map(order => (
            <div key={order._id} className="card admin-order-card">
              <div className="admin-order-header" onClick={() => setExpanded(expanded === order._id ? null : order._id)}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ fontWeight: 700, color: 'var(--primary-light)' }}>#{order.orderNumber}</span>
                    <span className={`badge ${STATUS_BADGE[order.status]}`}>{STATUSES.find(s => s.value === order.status)?.label || order.status}</span>
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>
                    {order.user?.name} · {order.user?.email} · {new Date(order.createdAt).toLocaleString()}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontWeight: 700, fontSize: 16 }}>₹{order.pricing?.total}</span>
                  {NEXT_STATUS[order.status] && (
                    <button
                      className="btn btn-accent btn-sm"
                      disabled={updating === order._id}
                      onClick={e => { e.stopPropagation(); handleStatusUpdate(order._id, NEXT_STATUS[order.status].value); }}
                    >
                      {updating === order._id ? '...' : NEXT_STATUS[order.status].label}
                    </button>
                  )}
                </div>
              </div>

              {expanded === order._id && (
                <div className="admin-order-details">
                  <div className="summary-divider" />
                  <div className="grid-2">
                    <div>
                      <h4 style={{ marginBottom: 12, color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase' }}>Pizza</h4>
                      <div style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 4 }}>
                        <div>🫓 <strong>Base:</strong> {order.pizza?.base?.name}</div>
                        <div>🍅 <strong>Sauce:</strong> {order.pizza?.sauce?.name}</div>
                        <div>🧀 <strong>Cheese:</strong> {order.pizza?.cheese?.name}</div>
                        {order.pizza?.veggies?.length > 0 && <div>🥬 <strong>Veggies:</strong> {order.pizza.veggies.map(v => v.name).join(', ')}</div>}
                        {order.pizza?.meats?.length > 0 && <div>🍗 <strong>Meats:</strong> {order.pizza.meats.map(m => m.name).join(', ')}</div>}
                      </div>
                    </div>
                    <div>
                      <h4 style={{ marginBottom: 12, color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase' }}>Delivery</h4>
                      <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.8 }}>
                        {order.deliveryAddress?.street}<br />
                        {order.deliveryAddress?.city}, {order.deliveryAddress?.state} {order.deliveryAddress?.pincode}
                      </div>
                      <div style={{ marginTop: 12, fontSize: 13 }}>
                        <span className={`badge ${order.payment?.status === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                          💳 {order.payment?.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  {/* Status History */}
                  {order.statusHistory?.length > 0 && (
                    <div style={{ marginTop: 16 }}>
                      <h4 style={{ marginBottom: 10, color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase' }}>Status History</h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                        {order.statusHistory.map((h, i) => (
                          <div key={i} style={{ display: 'flex', gap: 12, fontSize: 12, color: 'var(--text-muted)' }}>
                            <span>{new Date(h.updatedAt).toLocaleString()}</span>
                            <span className={`badge ${STATUS_BADGE[h.status]}`}>{h.status?.replace(/_/g, ' ')}</span>
                            {h.note && <span>{h.note}</span>}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
