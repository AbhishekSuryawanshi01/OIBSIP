import React, { useEffect, useState } from 'react';
import { adminAPI } from '../../services/api';
import { FiShoppingBag, FiUsers, FiDollarSign, FiAlertTriangle, FiClock } from 'react-icons/fi';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import './Admin.css';

const STATUS_BADGE = {
  order_received: 'badge-info', in_kitchen: 'badge-warning',
  sent_for_delivery: 'badge-primary', delivered: 'badge-success',
  cancelled: 'badge-danger', pending: 'badge-muted',
};
const STATUS_LABEL = {
  order_received: 'Received', in_kitchen: 'In Kitchen',
  sent_for_delivery: 'Delivering', delivered: 'Delivered',
  cancelled: 'Cancelled', pending: 'Pending',
};

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getDashboard()
      .then(res => setData(res.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-screen"><div className="spinner" /><p>Loading dashboard...</p></div>;
  if (!data) return <div className="page"><p>Failed to load dashboard.</p></div>;

  const { stats, lowStockItems, recentOrders } = data;

  const statCards = [
    { label: 'Total Orders', value: stats.totalOrders, icon: <FiShoppingBag />, color: 'var(--primary)' },
    { label: "Today's Orders", value: stats.todayOrders, icon: <FiClock />, color: 'var(--info)' },
    { label: 'Total Revenue', value: `₹${stats.totalRevenue?.toLocaleString()}`, icon: <FiDollarSign />, color: 'var(--success)' },
    { label: 'Total Users', value: stats.totalUsers, icon: <FiUsers />, color: 'var(--accent)' },
  ];

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ marginBottom: 28 }}>
        {statCards.map(s => (
          <div key={s.label} className="card admin-stat-card">
            <div className="admin-stat-icon" style={{ color: s.color, background: `${s.color}18` }}>{s.icon}</div>
            <div className="admin-stat-value">{s.value}</div>
            <div className="admin-stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={{ marginBottom: 28 }}>
        {/* Pending Orders Alert */}
        {stats.pendingOrders > 0 && (
          <div className="card" style={{ borderColor: 'rgba(245,158,11,0.4)', background: 'rgba(245,158,11,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <FiClock size={28} style={{ color: 'var(--warning)' }} />
              <div>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{stats.pendingOrders}</div>
                <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>Orders need attention</div>
              </div>
            </div>
          </div>
        )}

        {/* Low Stock Alert */}
        {stats.lowStockCount > 0 && (
          <div className="card" style={{ borderColor: 'rgba(239,68,68,0.4)', background: 'rgba(239,68,68,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <FiAlertTriangle size={28} style={{ color: 'var(--danger)' }} />
              <div>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{stats.lowStockCount}</div>
                <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>Low stock items</div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid-2">
        {/* Recent Orders */}
        <div className="card">
          <h3 style={{ marginBottom: 16 }}>Recent Orders</h3>
          {recentOrders.length === 0 ? (
            <p style={{ color: 'var(--text-muted)' }}>No orders yet.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {recentOrders.map(o => (
                <div key={o._id} className="recent-order-row">
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>#{o.orderNumber}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{o.user?.name}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span className={`badge ${STATUS_BADGE[o.status]}`}>{STATUS_LABEL[o.status]}</span>
                    <div style={{ fontSize: 13, fontWeight: 600, marginTop: 4 }}>₹{o.pricing?.total}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Low Stock Items */}
        <div className="card">
          <h3 style={{ marginBottom: 16 }}>⚠️ Low Stock Items</h3>
          {lowStockItems.length === 0 ? (
            <p style={{ color: 'var(--success)' }}>✅ All items well stocked!</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {lowStockItems.map(item => (
                <div key={item._id} className="low-stock-row">
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{item.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{item.category}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ color: 'var(--danger)', fontWeight: 700 }}>{item.stock} left</div>
                    <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>threshold: {item.threshold}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
