const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const Inventory = require('../models/Inventory');
const asyncHandler = require('express-async-handler');

// @desc    Get all pizza building options
// @route   GET /api/pizza/options
// @access  Private
router.get('/options', protect, asyncHandler(async (req, res) => {
  const categories = ['base', 'sauce', 'cheese', 'veggie', 'meat'];
  const result = {};

  for (const cat of categories) {
    result[cat] = await Inventory.find({
      category: cat,
      isAvailable: true,
      stock: { $gt: 0 },
    }).select('_id name description price imageUrl category');
  }

  res.json({ success: true, data: result });
}));

module.exports = router;
