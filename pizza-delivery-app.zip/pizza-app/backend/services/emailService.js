const nodemailer = require('nodemailer');

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
};

const sendEmail = async ({ to, subject, html, text }) => {
  const transporter = createTransporter();

  const mailOptions = {
    from: `"Pizza Delivery" <${process.env.EMAIL_FROM}>`,
    to,
    subject,
    html,
    text: text || '',
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`📧 Email sent: ${info.messageId}`);
    return info;
  } catch (error) {
    console.error(`❌ Email error: ${error.message}`);
    throw new Error('Email could not be sent');
  }
};

// Email Templates
const emailTemplates = {
  verifyEmail: (name, verifyUrl) => ({
    subject: '🍕 Verify Your Email - Pizza Delivery',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #e94560, #f5a623); padding: 40px; text-align: center;">
          <h1 style="margin: 0; font-size: 32px;">🍕 Pizza Delivery</h1>
        </div>
        <div style="padding: 40px;">
          <h2 style="color: #f5a623;">Hello ${name}!</h2>
          <p style="color: #ccc; line-height: 1.6;">Welcome to Pizza Delivery! Please verify your email to get started.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verifyUrl}" style="background: linear-gradient(135deg, #e94560, #f5a623); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">Verify Email</a>
          </div>
          <p style="color: #999; font-size: 14px;">This link expires in 24 hours. If you didn't register, ignore this email.</p>
        </div>
      </div>
    `,
  }),

  resetPassword: (name, resetUrl) => ({
    subject: '🔐 Reset Your Password - Pizza Delivery',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #e94560, #f5a623); padding: 40px; text-align: center;">
          <h1 style="margin: 0; font-size: 32px;">🍕 Pizza Delivery</h1>
        </div>
        <div style="padding: 40px;">
          <h2 style="color: #f5a623;">Password Reset</h2>
          <p style="color: #ccc;">Hi ${name}, you requested a password reset. Click below to reset it.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background: linear-gradient(135deg, #e94560, #f5a623); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold;">Reset Password</a>
          </div>
          <p style="color: #999; font-size: 14px;">This link expires in 30 minutes. If you didn't request this, ignore this email.</p>
        </div>
      </div>
    `,
  }),

  orderConfirmation: (name, order) => ({
    subject: `✅ Order Confirmed #${order.orderNumber} - Pizza Delivery`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #e94560, #f5a623); padding: 40px; text-align: center;">
          <h1 style="margin: 0;">🍕 Order Confirmed!</h1>
        </div>
        <div style="padding: 40px;">
          <h2 style="color: #f5a623;">Hi ${name}!</h2>
          <p style="color: #ccc;">Your order <strong>#${order.orderNumber}</strong> has been placed successfully!</p>
          <p style="color: #ccc;">Total: <strong style="color: #f5a623;">₹${order.pricing.total}</strong></p>
          <p style="color: #999; font-size: 14px;">We'll notify you as your order progresses.</p>
        </div>
      </div>
    `,
  }),

  orderStatusUpdate: (name, order) => ({
    subject: `📦 Order Update #${order.orderNumber} - Pizza Delivery`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #e94560, #f5a623); padding: 40px; text-align: center;">
          <h1 style="margin: 0;">🍕 Order Update</h1>
        </div>
        <div style="padding: 40px;">
          <h2 style="color: #f5a623;">Hi ${name}!</h2>
          <p style="color: #ccc;">Your order <strong>#${order.orderNumber}</strong> status has been updated to:</p>
          <div style="background: #16213e; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;">
            <span style="color: #f5a623; font-size: 20px; font-weight: bold;">${order.status.replace(/_/g, ' ').toUpperCase()}</span>
          </div>
        </div>
      </div>
    `,
  }),

  lowStockAlert: (items) => ({
    subject: '⚠️ Low Stock Alert - Pizza Delivery Admin',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: #e94560; padding: 40px; text-align: center;">
          <h1 style="margin: 0;">⚠️ Low Stock Alert</h1>
        </div>
        <div style="padding: 40px;">
          <h2 style="color: #f5a623;">Inventory Alert</h2>
          <p style="color: #ccc;">The following items are running low:</p>
          <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
              <tr style="background: #16213e;">
                <th style="padding: 12px; text-align: left; color: #f5a623;">Item</th>
                <th style="padding: 12px; text-align: left; color: #f5a623;">Category</th>
                <th style="padding: 12px; text-align: left; color: #f5a623;">Stock</th>
                <th style="padding: 12px; text-align: left; color: #f5a623;">Threshold</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(item => `
                <tr style="border-bottom: 1px solid #333;">
                  <td style="padding: 12px; color: #fff;">${item.name}</td>
                  <td style="padding: 12px; color: #ccc;">${item.category}</td>
                  <td style="padding: 12px; color: #e94560; font-weight: bold;">${item.stock}</td>
                  <td style="padding: 12px; color: #999;">${item.threshold}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <p style="color: #999; margin-top: 20px; font-size: 14px;">Please restock these items to continue smooth operations.</p>
        </div>
      </div>
    `,
  }),
};

module.exports = { sendEmail, emailTemplates };
