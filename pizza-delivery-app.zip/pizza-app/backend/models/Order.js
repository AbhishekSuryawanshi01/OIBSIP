const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    orderNumber: {
      type: String,
      unique: true,
    },
    pizza: {
      base: {
        item: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory' },
        name: String,
        price: Number,
      },
      sauce: {
        item: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory' },
        name: String,
        price: Number,
      },
      cheese: {
        item: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory' },
        name: String,
        price: Number,
      },
      veggies: [
        {
          item: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory' },
          name: String,
          price: Number,
        },
      ],
      meats: [
        {
          item: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory' },
          name: String,
          price: Number,
        },
      ],
    },
    pricing: {
      subtotal: { type: Number, required: true },
      tax: { type: Number, default: 0 },
      deliveryFee: { type: Number, default: 49 },
      total: { type: Number, required: true },
    },
    deliveryAddress: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      pincode: { type: String, required: true },
    },
    status: {
      type: String,
      enum: ['pending', 'order_received', 'in_kitchen', 'sent_for_delivery', 'delivered', 'cancelled'],
      default: 'pending',
    },
    statusHistory: [
      {
        status: String,
        updatedAt: { type: Date, default: Date.now },
        note: String,
      },
    ],
    payment: {
      razorpayOrderId: String,
      razorpayPaymentId: String,
      razorpaySignature: String,
      method: String,
      status: {
        type: String,
        enum: ['pending', 'paid', 'failed', 'refunded'],
        default: 'pending',
      },
      paidAt: Date,
    },
    notes: String,
  },
  { timestamps: true }
);

// Generate order number before saving
orderSchema.pre('save', async function (next) {
  if (!this.orderNumber) {
    const count = await this.constructor.countDocuments();
    this.orderNumber = `PZA${Date.now().toString().slice(-6)}${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
