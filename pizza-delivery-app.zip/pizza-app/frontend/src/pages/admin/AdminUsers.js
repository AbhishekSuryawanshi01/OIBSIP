import React, { useEffect, useState } from 'react';
import { userAPI } from '../../services/api';
import toast from 'react-hot-toast';
import { FiUsers } from 'react-icons/fi';
import './Admin.css';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toggling, setToggling] = useState(null);

  const fetchUsers = () => {
    setLoading(true);
    userAPI.getAllUsers()
      .then(res => setUsers(res.data.data))
      .catch(() => toast.error('Failed to load users'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleToggle = async (id) => {
    setToggling(id);
    try {
      const res = await userAPI.toggleStatus(id);
      toast.success(res.data.message);
      fetchUsers();
    } catch (err) {
      toast.error('Failed to update status');
    } finally { setToggling(null); }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Users</h1>
        <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{users.length} registered users</span>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 60 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
      ) : users.length === 0 ? (
        <div className="empty-state card">
          <FiUsers size={48} style={{ color: 'var(--text-dim)' }} />
          <h3>No users yet</h3>
        </div>
      ) : (
        <div className="card table-wrapper">
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Email Verified</th>
                <th>Joined</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user._id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 34, height: 34, background: 'linear-gradient(135deg, var(--primary), var(--primary-light))', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
                        {user.name?.[0]?.toUpperCase()}
                      </div>
                      <span style={{ fontWeight: 600 }}>{user.name}</span>
                    </div>
                  </td>
                  <td style={{ color: 'var(--text-muted)' }}>{user.email}</td>
                  <td style={{ color: 'var(--text-muted)' }}>{user.phone || '—'}</td>
                  <td>
                    <span className={`badge ${user.isEmailVerified ? 'badge-success' : 'badge-warning'}`}>
                      {user.isEmailVerified ? 'Verified' : 'Pending'}
                    </span>
                  </td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{new Date(user.createdAt).toLocaleDateString()}</td>
                  <td>
                    <span className={`badge ${user.isActive ? 'badge-success' : 'badge-danger'}`}>
                      {user.isActive ? 'Active' : 'Deactivated'}
                    </span>
                  </td>
                  <td>
                    <button
                      className={`btn btn-sm ${user.isActive ? 'btn-danger' : 'btn-accent'}`}
                      disabled={toggling === user._id}
                      onClick={() => handleToggle(user._id)}
                    >
                      {toggling === user._id ? '...' : user.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
