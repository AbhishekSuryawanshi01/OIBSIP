const asyncHandler = require('express-async-handler');
const Inventory = require('../models/Inventory');

// @desc    Get all inventory items
// @route   GET /api/inventory
// @access  Private/Admin
const getAllInventory = asyncHandler(async (req, res) => {
  const { category } = req.query;
  const filter = category ? { category } : {};
  const items = await Inventory.find(filter).sort({ category: 1, name: 1 });
  res.json({ success: true, count: items.length, data: items });
});

// @desc    Get inventory by category (public - for pizza builder)
// @route   GET /api/inventory/available/:category
// @access  Private
const getAvailableByCategory = asyncHandler(async (req, res) => {
  const items = await Inventory.find({
    category: req.params.category,
    isAvailable: true,
    stock: { $gt: 0 },
  }).select('name description price imageUrl category stock');

  res.json({ success: true, data: items });
});

// @desc    Get all available items grouped by category
// @route   GET /api/inventory/available
// @access  Private
const getAllAvailable = asyncHandler(async (req, res) => {
  const categories = ['base', 'sauce', 'cheese', 'veggie', 'meat'];
  const result = {};

  for (const cat of categories) {
    result[cat] = await Inventory.find({
      category: cat,
      isAvailable: true,
      stock: { $gt: 0 },
    }).select('name description price imageUrl category stock');
  }

  res.json({ success: true, data: result });
});

// @desc    Add inventory item
// @route   POST /api/inventory
// @access  Private/Admin
const addInventoryItem = asyncHandler(async (req, res) => {
  const item = await Inventory.create(req.body);
  res.status(201).json({ success: true, data: item });
});

// @desc    Update inventory item
// @route   PUT /api/inventory/:id
// @access  Private/Admin
const updateInventoryItem = asyncHandler(async (req, res) => {
  const item = await Inventory.findById(req.params.id);
  if (!item) {
    res.status(404);
    throw new Error('Inventory item not found');
  }

  // Reset alert if stock is restocked above threshold
  if (req.body.stock && req.body.stock > item.threshold) {
    req.body.lowStockAlertSent = false;
  }

  const updated = await Inventory.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.json({ success: true, data: updated });
});

// @desc    Delete inventory item
// @route   DELETE /api/inventory/:id
// @access  Private/Admin
const deleteInventoryItem = asyncHandler(async (req, res) => {
  const item = await Inventory.findById(req.params.id);
  if (!item) {
    res.status(404);
    throw new Error('Inventory item not found');
  }
  await item.deleteOne();
  res.json({ success: true, message: 'Item deleted successfully' });
});

// @desc    Get low stock items
// @route   GET /api/inventory/low-stock
// @access  Private/Admin
const getLowStockItems = asyncHandler(async (req, res) => {
  const items = await Inventory.find({
    $expr: { $lte: ['$stock', '$threshold'] },
  });
  res.json({ success: true, count: items.length, data: items });
});

// @desc    Restock an item
// @route   PUT /api/inventory/:id/restock
// @access  Private/Admin
const restockItem = asyncHandler(async (req, res) => {
  const { quantity } = req.body;
  const item = await Inventory.findById(req.params.id);

  if (!item) {
    res.status(404);
    throw new Error('Item not found');
  }

  item.stock += Number(quantity);
  if (item.stock > item.threshold) {
    item.lowStockAlertSent = false;
  }
  await item.save();

  res.json({ success: true, data: item });
});

module.exports = {
  getAllInventory,
  getAvailableByCategory,
  getAllAvailable,
  addInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getLowStockItems,
  restockItem,
};
