import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { paymentAPI, orderAPI } from '../../services/api';
import toast from 'react-hot-toast';
import './User.css';

const loadRazorpay = () =>
  new Promise((resolve) => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });

export default function Checkout() {
  const { user } = useAuth();
  const { customPizza, calculatePricing, resetPizza } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({
    street: user?.address?.street || '',
    city: user?.address?.city || '',
    state: user?.address?.state || '',
    pincode: user?.address?.pincode || '',
  });

  const pricing = calculatePricing();

  const buildOrderPayload = (paymentData) => ({
    pizza: {
      base: customPizza.base ? { item: customPizza.base._id, name: customPizza.base.name, price: customPizza.base.price } : undefined,
      sauce: customPizza.sauce ? { item: customPizza.sauce._id, name: customPizza.sauce.name, price: customPizza.sauce.price } : undefined,
      cheese: customPizza.cheese ? { item: customPizza.cheese._id, name: customPizza.cheese.name, price: customPizza.cheese.price } : undefined,
      veggies: customPizza.veggies.map(v => ({ item: v._id, name: v.name, price: v.price })),
      meats: customPizza.meats.map(m => ({ item: m._id, name: m.name, price: m.price })),
    },
    deliveryAddress: address,
    pricing,
    payment: { ...paymentData, status: 'paid', paidAt: new Date() },
  });

  const handlePayment = async () => {
    if (!address.street || !address.city || !address.state || !address.pincode) {
      toast.error('Please fill in your delivery address');
      return;
    }

    setLoading(true);
    try {
      const loaded = await loadRazorpay();
      if (!loaded) { toast.error('Razorpay failed to load. Please try again.'); setLoading(false); return; }

      const { data: { data: rzpOrder } } = await paymentAPI.createOrder(pricing.total);

      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY_ID || rzpOrder.keyId,
        amount: rzpOrder.amount,
        currency: rzpOrder.currency,
        name: 'PizzaCraft',
        description: 'Custom Pizza Order',
        order_id: rzpOrder.orderId,
        prefill: { name: user?.name, email: user?.email, contact: user?.phone },
        theme: { color: '#e8401c' },
        handler: async (response) => {
          try {
            // Verify payment
            await paymentAPI.verify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });

            // Create order in DB
            const orderPayload = buildOrderPayload({
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
              method: 'razorpay',
            });

            const { data: { data: order } } = await orderAPI.create(orderPayload);
            resetPizza();
            toast.success('🎉 Order placed successfully!');
            navigate(`/my-orders/${order._id}`);
          } catch (err) {
            toast.error('Payment verification failed');
          }
        },
        modal: {
          ondismiss: () => { setLoading(false); toast('Payment cancelled'); }
        }
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Payment initiation failed');
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <h1 className="page-title" style={{ marginBottom: 28 }}>🛒 Checkout</h1>

      <div className="checkout-layout">
        {/* Left: Address */}
        <div>
          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ marginBottom: 20 }}>📍 Delivery Address</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="form-group">
                <label className="form-label">Street Address</label>
                <input className="form-input" placeholder="123 Main St" value={address.street} onChange={e => setAddress({ ...address, street: e.target.value })} />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">City</label>
                  <input className="form-input" placeholder="Mumbai" value={address.city} onChange={e => setAddress({ ...address, city: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">State</label>
                  <input className="form-input" placeholder="Maharashtra" value={address.state} onChange={e => setAddress({ ...address, state: e.target.value })} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Pincode</label>
                <input className="form-input" placeholder="400001" value={address.pincode} onChange={e => setAddress({ ...address, pincode: e.target.value })} />
              </div>
            </div>
          </div>

          {/* Pizza Summary */}
          <div className="card">
            <h3 style={{ marginBottom: 16 }}>🍕 Your Pizza</h3>
            <div className="pizza-summary">
              <div className="summary-row"><span className="summary-key">Base</span><span className="summary-val">{customPizza.base?.name} — ₹{customPizza.base?.price}</span></div>
              <div className="summary-row"><span className="summary-key">Sauce</span><span className="summary-val">{customPizza.sauce?.name} — ₹{customPizza.sauce?.price}</span></div>
              <div className="summary-row"><span className="summary-key">Cheese</span><span className="summary-val">{customPizza.cheese?.name} — ₹{customPizza.cheese?.price}</span></div>
              {customPizza.veggies.length > 0 && (
                <div className="summary-row"><span className="summary-key">Veggies</span><span className="summary-val">{customPizza.veggies.map(v => `${v.name} (₹${v.price})`).join(', ')}</span></div>
              )}
              {customPizza.meats.length > 0 && (
                <div className="summary-row"><span className="summary-key">Meats</span><span className="summary-val">{customPizza.meats.map(m => `${m.name} (₹${m.price})`).join(', ')}</span></div>
              )}
            </div>
          </div>
        </div>

        {/* Right: Order Summary */}
        <div>
          <div className="card" style={{ position: 'sticky', top: 24 }}>
            <h3 style={{ marginBottom: 20 }}>Order Summary</h3>
            <div className="pricing-breakdown">
              <div className="pricing-row"><span>Subtotal</span><span>₹{pricing.subtotal}</span></div>
              <div className="pricing-row"><span>Tax (5%)</span><span>₹{pricing.tax}</span></div>
              <div className="pricing-row"><span>Delivery Fee</span><span>₹{pricing.deliveryFee}</span></div>
              <div className="summary-divider" />
              <div className="pricing-row pricing-total"><span>Total</span><span>₹{pricing.total}</span></div>
            </div>

            <div style={{ marginTop: 24, padding: 14, background: 'var(--bg-card2)', borderRadius: 8, marginBottom: 20 }}>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
                🔒 Secure payment via Razorpay (Test Mode)<br />
                <span style={{ color: 'var(--accent)' }}>Use test card: 4111 1111 1111 1111</span>
              </p>
            </div>

            <button className="btn btn-primary btn-full btn-lg" onClick={handlePayment} disabled={loading}>
              {loading ? <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} /> : '💳'}
              {loading ? 'Processing...' : `Pay ₹${pricing.total}`}
            </button>

            <button className="btn btn-ghost btn-full" style={{ marginTop: 10 }} onClick={() => navigate('/build-pizza')}>
              ← Edit Pizza
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
