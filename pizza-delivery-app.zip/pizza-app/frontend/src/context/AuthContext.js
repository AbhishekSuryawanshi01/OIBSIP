import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [loading, setLoading] = useState(false);

  const login = async (email, password) => {
    const res = await authAPI.login({ email, password });
    const { token: tok, user: u } = res.data;
    localStorage.setItem('token', tok);
    localStorage.setItem('user', JSON.stringify(u));
    setToken(tok);
    setUser(u);
    return u;
  };

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
  }, []);

  const updateUser = (updatedUser) => {
    const merged = { ...user, ...updatedUser };
    localStorage.setItem('user', JSON.stringify(merged));
    setUser(merged);
  };

  const refreshUser = useCallback(async () => {
    try {
      const res = await authAPI.getMe();
      const u = res.data.user;
      localStorage.setItem('user', JSON.stringify(u));
      setUser(u);
    } catch {
      logout();
    }
  }, [logout]);

  useEffect(() => {
    if (token) refreshUser();
  }, []); // eslint-disable-line

  return (
    <AuthContext.Provider value={{ user, token, loading, setLoading, login, logout, updateUser, refreshUser, isAdmin: user?.role === 'admin', isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
