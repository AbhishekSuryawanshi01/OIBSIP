import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { orderAPI } from '../../services/api';
import toast from 'react-hot-toast';
import './User.css';

const STATUS_BADGE = {
  pending: 'badge-muted', order_received: 'badge-info', in_kitchen: 'badge-warning',
  sent_for_delivery: 'badge-primary', delivered: 'badge-success', cancelled: 'badge-danger',
};
const STATUS_LABEL = {
  pending: 'Pending', order_received: 'Order Received', in_kitchen: 'In Kitchen 👨‍🍳',
  sent_for_delivery: 'Out for Delivery 🛵', delivered: 'Delivered ✅', cancelled: 'Cancelled ❌',
};

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    orderAPI.getMyOrders()
      .then(res => setOrders(res.data.data))
      .catch(() => toast.error('Failed to load orders'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">My Orders</h1>
      </div>

      {orders.length === 0 ? (
        <div className="empty-state card">
          <div style={{ fontSize: 64 }}>🍕</div>
          <h3>No orders yet</h3>
          <p>Start building your first pizza!</p>
          <Link to="/build-pizza" className="btn btn-primary" style={{ marginTop: 16 }}>Build a Pizza</Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {orders.map(order => (
            <Link to={`/my-orders/${order._id}`} key={order._id} className="order-card card" style={{ textDecoration: 'none' }}>
              <div className="order-card-left">
                <div className="order-number">#{order.orderNumber}</div>
                <div className="order-items" style={{ marginTop: 4 }}>
                  {[order.pizza?.base?.name, order.pizza?.sauce?.name, order.pizza?.cheese?.name].filter(Boolean).join(' · ')}
                  {order.pizza?.veggies?.length > 0 && ` + ${order.pizza.veggies.length} veggies`}
                  {order.pizza?.meats?.length > 0 && ` + ${order.pizza.meats.length} meats`}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 4 }}>
                  {new Date(order.createdAt).toLocaleString()}
                </div>
              </div>
              <div className="order-card-right">
                <span className={`badge ${STATUS_BADGE[order.status]}`}>{STATUS_LABEL[order.status]}</span>
                <div className="order-price">₹{order.pricing?.total}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Order Detail ─────────────────────────────────────────
export function OrderDetail() {
  const { id } = require('react-router-dom').useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    orderAPI.getById(id)
      .then(res => setOrder(res.data.data))
      .catch(() => toast.error('Order not found'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!order) return <div className="page"><p>Order not found.</p></div>;

  const steps = [
    { key: 'order_received', label: 'Order Received', emoji: '✅' },
    { key: 'in_kitchen', label: 'In Kitchen', emoji: '👨‍🍳' },
    { key: 'sent_for_delivery', label: 'Out for Delivery', emoji: '🛵' },
    { key: 'delivered', label: 'Delivered', emoji: '🎉' },
  ];

  const stepIndex = steps.findIndex(s => s.key === order.status);

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Order #{order.orderNumber}</h1>
        <span className={`badge ${STATUS_BADGE[order.status]}`} style={{ fontSize: 14, padding: '6px 14px' }}>
          {STATUS_LABEL[order.status]}
        </span>
      </div>

      {/* Progress Tracker */}
      {order.status !== 'cancelled' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <h3 style={{ marginBottom: 20 }}>Order Progress</h3>
          <div className="progress-track">
            {steps.map((s, i) => (
              <div key={s.key} className={`progress-step ${i <= stepIndex ? 'progress-step--done' : ''} ${i === stepIndex ? 'progress-step--active' : ''}`}>
                <div className="progress-circle">{s.emoji}</div>
                <div className="progress-label">{s.label}</div>
                {i < steps.length - 1 && <div className={`progress-line ${i < stepIndex ? 'progress-line--done' : ''}`} />}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid-2">
        {/* Pizza Details */}
        <div className="card">
          <h3 style={{ marginBottom: 16 }}>🍕 Pizza Details</h3>
          <div className="pizza-summary">
            <div className="summary-row"><span className="summary-key">Base</span><span className="summary-val">{order.pizza?.base?.name}</span></div>
            <div className="summary-row"><span className="summary-key">Sauce</span><span className="summary-val">{order.pizza?.sauce?.name}</span></div>
            <div className="summary-row"><span className="summary-key">Cheese</span><span className="summary-val">{order.pizza?.cheese?.name}</span></div>
            {order.pizza?.veggies?.length > 0 && (
              <div className="summary-row"><span className="summary-key">Veggies</span><span className="summary-val">{order.pizza.veggies.map(v => v.name).join(', ')}</span></div>
            )}
            {order.pizza?.meats?.length > 0 && (
              <div className="summary-row"><span className="summary-key">Meats</span><span className="summary-val">{order.pizza.meats.map(m => m.name).join(', ')}</span></div>
            )}
          </div>
          <div className="summary-divider" />
          <div className="pricing-breakdown">
            <div className="pricing-row"><span>Subtotal</span><span>₹{order.pricing?.subtotal}</span></div>
            <div className="pricing-row"><span>Tax</span><span>₹{order.pricing?.tax}</span></div>
            <div className="pricing-row"><span>Delivery</span><span>₹{order.pricing?.deliveryFee}</span></div>
            <div className="pricing-row pricing-total"><span>Total</span><span>₹{order.pricing?.total}</span></div>
          </div>
        </div>

        {/* Delivery & Payment */}
        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            <h3 style={{ marginBottom: 16 }}>📍 Delivery Address</h3>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.8 }}>
              {order.deliveryAddress?.street}<br />
              {order.deliveryAddress?.city}, {order.deliveryAddress?.state}<br />
              {order.deliveryAddress?.pincode}
            </p>
          </div>
          <div className="card">
            <h3 style={{ marginBottom: 16 }}>💳 Payment</h3>
            <div className="summary-row"><span className="summary-key">Status</span><span className={`badge ${order.payment?.status === 'paid' ? 'badge-success' : 'badge-warning'}`}>{order.payment?.status}</span></div>
            <div className="summary-row" style={{ marginTop: 8 }}><span className="summary-key">ID</span><span className="summary-val" style={{ fontSize: 12 }}>{order.payment?.razorpayPaymentId || '—'}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
